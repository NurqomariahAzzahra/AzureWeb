@extends('template.layout')


@section('content')
<div class="container">
  <div class="row">
    <div class="col-lg-12 text-center">
      <h1 class="mt-5">BIODATA</h1>
      <p class="lead">about</p>
      <ul class="list-unstyled">
        <li>Nurqomariah Azzahra</li>
        <li>1915101029 </li>
        <!-- <li><a href="https://github.com/andika-eka/stat-web"> github repository</a></li> -->
      </ul>
    </div>
  </div>
</div>
@endsection
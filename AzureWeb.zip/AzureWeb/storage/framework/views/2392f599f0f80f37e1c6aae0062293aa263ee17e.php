


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1 class="mt-5">Data Mahasiswa</h1>
            <p class="lead">hasil pengolahan data</p>

        </div>
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-sm">
                    <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 1 maximum</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($max1); ?></h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 2 maximum</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($max2); ?></h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 3 maximum</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($max3); ?></h5>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <div class="card text-white bg-danger  mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 1 minimum</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($min1); ?></h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card text-white bg-danger  mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 2 minimum</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($min2); ?></h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card text-white bg-danger  mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 3 minimum</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($min3); ?></h5>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <div class="card border-dark mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 1 rata-rata</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($avg1); ?></h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card border-dark mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 2 rata-rata</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($avg2); ?></h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card border-dark mb-3" style="max-width: 18rem;">
                        <div class="card-header"><b>nilai 3 rata-rata</b></div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($avg3); ?></h5>

                        </div>
                    </div>
                </div>
            </div>

            <hr>


            <div class="container">
                <div class="row">
                    <div class="col-lg d-flex justify-content-center text-center">
                        <div class="card text-white bg-primary " style="min-width: 30rem;">
                            <div class="card-header"><b>nilai maximum</b></div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e(max($max1,$max2,$max3)); ?></h5>

                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-lg d-flex justify-content-center text-center">
                        <div class="card text-white bg-danger " style="min-width: 30rem;">
                            <div class="card-header"><b>nilai minimum</b></div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e(min($min1,$min2,$min3)); ?></h5>

                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-lg d-flex justify-content-center text-center">
                        <div class="card border-dark " style="min-width: 30rem;">
                            <div class="card-header"><b>nilai rata-rata</b></div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($avgAll); ?></h5>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<hr>
<div class="container text-center">
    <div class="row">
        <div class="col-sm">
            <h4>nilai 1</h4>
        </div>
        <div class="col-sm">
            <h4>nilai 2</h4>
        </div>
        <div class="col-sm">
            <h4>nilai 3</h4>
        </div>


    </div>
    <div class="row">
        <div class="col-sm">
            <table class="table table-striped table-dark">
                <thead>
                    <tr>
                        <td scope="col">nilai</td>
                        <td scope="col">Frekuensi</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $frek1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td> <?php echo e($frek->nilai); ?> </td>
                        <td> <?php echo e($frek->frek); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <div class="col-sm">
            <table class="table table-striped table-dark">
                <thead>
                    <tr>
                        <td scope="col">nilai</td>
                        <td scope="col">Frekuensi</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $frek2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td> <?php echo e($frek->nilai); ?> </td>
                        <td> <?php echo e($frek->frek); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <div class="col-sm">
            <table class="table table-striped table-dark">
                <thead>
                    <tr>
                        <td scope="col">nilai</td>
                        <td scope="col">Frekuensi</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $frek1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td> <?php echo e($frek->nilai); ?> </td>
                        <td> <?php echo e($frek->frek); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\stat-web\resources\views/pages/info.blade.php ENDPATH**/ ?>
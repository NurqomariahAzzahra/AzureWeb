


<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-lg-12 text-center">
      <h1 class="mt-5">BIODATA</h1>
      <p class="lead">about</p>
      <ul class="list-unstyled">
        <li>Nurqomariah Azzahra</li>
        <li>1915101029 </li>
        <!-- <li><a href="https://github.com/andika-eka/stat-web"> github repository</a></li> -->
      </ul>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\stat-web\resources\views/pages/about.blade.php ENDPATH**/ ?>



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1 class="mt-5">Data Mahasiswa</h1>
            <p class="lead">data</p>
            <ul class="list-unstyled">
                <li><a href="/Data/create" class="btn btn-primary" name='new'>Tambahkan Data</a></li>

            </ul>
        </div>
    </div>
    <?php if(count($data) > 0): ?>
    <table class="table table-dark">
        <thead>
            <tr>
                <th scope="col">nama</th>
                <th scope="col">nilai 1</th>
                <th scope="col">nilai 2</th>
                <th scope="col">nilai 3</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div title="<?php echo e($item -> keterangan); ?>"><?php echo e($item -> nama); ?> </div>
                </td>

                <td><?php echo e($item -> nilai_1); ?></td>
                <td><?php echo e($item -> nilai_2); ?></td>
                <td><?php echo e($item -> nilai_3); ?>

                <td>
                    <a href="/Data/<?php echo e($item -> id); ?>/edit" class="btn btn-primary" name='edit'>edit</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>data not found :( </p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\stat-web\resources\views/data/index.blade.php ENDPATH**/ ?>